// test/widget_test.dart
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:banking_app/main.dart';

void main() {
  testWidgets('Banking App launches and shows Login Screen', (WidgetTester tester) async {
    // Build the app
    await tester.pumpWidget(const BankingApp());

    // Wait for any async loading
    await tester.pumpAndSettle();

    // Verify: App starts on Login Screen
    expect(find.text('Welcome Back!'), findsOneWidget);
    expect(find.text('Login to your account'), findsOneWidget);

    // Verify: Mobile number field exists
    expect(find.widgetWithText(TextFormField, 'Mobile Number'), findsOneWidget);

    // Verify: Password field exists
    expect(find.widgetWithText(TextFormField, 'Password'), findsOneWidget);

    // Verify: Login button exists
    expect(find.widgetWithText(ElevatedButton, 'Login'), findsOneWidget);
  });

  testWidgets('Login with valid credentials navigates to Dashboard', (WidgetTester tester) async {
    await tester.pumpWidget(const BankingApp());
    await tester.pumpAndSettle();

    // Enter valid mobile (10 digits)
    await tester.enterText(
      find.widgetWithText(TextFormField, 'Mobile Number'),
      '9876543210',
    );

    // Enter any password
    await tester.enterText(
      find.widgetWithText(TextFormField, 'Password'),
      'password123',
    );

    // Tap Login
    await tester.tap(find.widgetWithText(ElevatedButton, 'Login'));
    await tester.pumpAndSettle(); // Wait for navigation

    // Verify: Navigated to Dashboard
    expect(find.text('Available Balance'), findsOneWidget);
    expect(find.text('₹12,450.00'), findsOneWidget);
    expect(find.text('Quick Actions'), findsOneWidget);
  });
}